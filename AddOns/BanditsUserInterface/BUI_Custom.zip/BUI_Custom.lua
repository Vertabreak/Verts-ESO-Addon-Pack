--[[
This module can be used to add own events for Notifications. Thx to Zoom for idea to give players ability to add custom events.

IDs can be taked:
	from Bnadits Log (Settings>Bandits UI>Combat statistics>Log)
	from ingame encounterlog
Value:
	must be "true" by default
	1-99 if you want to assign custom timer value (in sec)
	100 if you want to receive notification from event targeted to another player
	100-199 if you want to receive notification from event targeted to another player with custom timer (100 + timer value in sec)
Slash command /ab [id] can be helpful
--]]

BUI.CustomNotifications={
--Examples:

--World notifications
[4632]=true,--Screech. Werebat.
[36986]=false,--Void. You can disable some default Bandits UI notifications.
--[2969]=true,--Pound. Zombie. You can comment useless events.
[7268]=1.2,--Leech. Nyx. Value was customly set because this ability have 5.3 sec cast time but effect will be applied in 1.2 sec.

--Elsweyr Dragons
[123372]=100,--Tail Whip. Dragon. "100" means that you receive notification even when dragon whips another player cause this attack can hit you too.
}